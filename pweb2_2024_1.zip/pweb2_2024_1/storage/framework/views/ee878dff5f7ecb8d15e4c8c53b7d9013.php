<?php $__env->startSection('conteudo'); ?>

    <?php
        if(!empty($dado->id)){
            $route = route('aluno.update',$dado->id);
        } else {
            $route = route('aluno.store') ;
        }
    ?>

    <form action="<?php echo e($route); ?>" method="post">

        <?php echo csrf_field(); ?>


        <label for="">Nome</label><br>
        <input type="text" name="nome" value="<?php echo e($dado->nome); ?>"><br>

        <label for="">Telefone</label><br>
        <input type="text" name="telefone" value="<?php echo e(old('telefone')); ?>"><br>

        <label for="">CPF</label><br>
        <input type="text" name="cpf" value="<?php echo e(old('cpf')); ?>"><br>

        <button type="submit">Salvar</button>
        <button><a href="<?php echo e(url('aluno')); ?>">Voltar</a></button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb2_2024_1\resources\views/aluno/form.blade.php ENDPATH**/ ?>